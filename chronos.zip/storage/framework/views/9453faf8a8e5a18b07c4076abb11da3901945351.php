<footer class="footer pt-0">
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer><?php /**PATH C:\xampp\htdocs\chronos\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>