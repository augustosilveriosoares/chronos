
<?php $i = 0; $y =1 ;$maxcolumn = 4; $size = count($dashboardadv); ?>
<div class="row">
<?php $__currentLoopData = $dashboardadv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-lg-3 col-md -4 col-sm-12 mt-7">
                <div class="card">
                    <div class="row justify-content-center mb-6">
                        <div class="col-lg-3 order-lg-2">
                            <div class="card-profile-image">

                                    <img src="<?php echo e($adv->picture); ?>" class="rounded-circle">

                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <h3 class="card-title mb-3 text-center"><?php echo e($adv->name); ?></h3>
                        <h4 class="text-muted text-center"><strong class="text-primary"><?php echo e($adv->total); ?></strong> Atendimentos</h4>

                    </div>
                    <ul class="list-group list-group-flush">

                        <li class="list-group-item"><h4 class="text-muted text-center"><strong class="text-primary"><?php echo e($adv->totalagendado?? '0'); ?></strong> Agendados</h4></li>
                        <li class="list-group-item"><h4 class="text-muted text-center"><strong class="text-primary"><?php echo e($adv->totalconcluido?? '0'); ?></strong> Concluídos</h4></li>
                        <li class="list-group-item"><h4 class="text-muted text-center"><strong class="text-primary"><?php echo e($adv->totalprocesso?? '0'); ?></strong> Processos</h4></li>

                    </ul>
                </div>
    </div>
    
    <?php if($size <= $maxcolumn && $y === $size): ?>
        </div>
    <?php endif; ?>
    
    <?php if($i === $maxcolumn): ?>
        
        <?php if($size === $y): ?>
            
            </div>
        <?php endif; ?>
        <?php if($size > $y): ?>
            
            </div>
            <div class="row">
        <?php endif; ?>
        
        <?php  $i = 0;  ?>
    <?php endif; ?>
    
    <?php  $i = $i+1;  ?>
    
    <?php  $y = $y+1;  ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>












<?php /**PATH C:\xampp\htdocs\chronos\resources\views/layouts/headers/advogados.blade.php ENDPATH**/ ?>