<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
           <?php echo e($slot); ?> 
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\chronos\resources\views/layouts/headers/auth.blade.php ENDPATH**/ ?>