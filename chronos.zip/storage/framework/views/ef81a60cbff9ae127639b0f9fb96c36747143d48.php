<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('layouts.headers.auth'); ?>

    <?php if (isset($__componentOriginalf553482b463f6cda44d25fdb8f98d9a83d364bb5)): ?>
<?php $component = $__componentOriginalf553482b463f6cda44d25fdb8f98d9a83d364bb5; ?>
<?php unset($__componentOriginalf553482b463f6cda44d25fdb8f98d9a83d364bb5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12 order-xl-1">
                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3><?php echo e(__('Atendimento')); ?>  </h3>
                                <span class="text-muted small">Criado em <?php echo e(date('d-m-Y', strtotime($atendimento->datacadastro))); ?> </span>
                            </div>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(route('atendimentos.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Voltar')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if($atendimento->id): ?>
                            <form method="post" action="<?php echo e(route('atendimentos.update', $atendimento)); ?>" autocomplete="off">
                                <?php echo method_field('put'); ?>
                        <?php else: ?>
                            <form method="post" action="<?php echo e(route('atendimentos.store', $atendimento)); ?>" autocomplete="off">
                        <?php endif; ?>
                            <?php echo csrf_field(); ?>
                                <div class="row">

                                            <div class="form-group<?php echo e($errors->has('datacadastro') ? ' has-danger' : ''); ?>">
                                                <input type="hidden" name="datacadastro" id="" class="form-control<?php echo e($errors->has('datacadastro') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Data')); ?>" value="<?php echo e(date('Y-m-d\TH:i', strtotime($atendimento->datacadastro))); ?>"  >
                                                <?php echo $__env->make('alerts.feedback', ['field' => 'datacadastro'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>


                                            <div class="col-lg-5 col-sm-12">
                                                <div class="form-group<?php echo e($errors->has('nome') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-nome"><?php echo e(__('Nome')); ?></label>
                                                    <input type="text" name="nome" id="input-nome" class="form-control<?php echo e($errors->has('nome') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Nome')); ?>" value="<?php echo e(old('nome', $atendimento->nome??'')); ?>" required autofocus>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>

                                            </div>
                                            <div class="col-lg-1 col-sm-6">
                                                <div class="form-group<?php echo e($errors->has('idade') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-idade"><?php echo e(__('Idade')); ?></label>
                                                    <input type="text" name="idade" id="input-idade" class="form-control<?php echo e($errors->has('idade') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Idade')); ?>" value="<?php echo e(old('nome', $atendimento->idade??'')); ?>" required autofocus>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'idade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>

                                            </div>
                                            <div class="col-lg-1 col-sm-6">
                                                <div class="form-group<?php echo e($errors->has('contribuicao') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-contribuicao"><?php echo e(__('Contribuição')); ?></label>
                                                    <input type="text" name="anoscontribuicao" id="input-anoscontribuicao" class="form-control<?php echo e($errors->has('anoscontribuicao') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Contribuição')); ?>" value="<?php echo e(old('anoscontribuicao', $atendimento->anoscontribuicao ??'')); ?>" required autofocus>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'anoscontribuicao'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>

                                            </div>
                                            <div class="col-lg-2 col-sm-12">
                                                <div class="form-group<?php echo e($errors->has('sexo_id') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-idade"><?php echo e(__('Sexo')); ?></label>
                                                    <select name="sexo_id" id="input-sexo" class="form-control<?php echo e($errors->has('sexo_id') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Sexo')); ?>" required>
                                                        <option value="">-</option>
                                                        <?php $__currentLoopData = $sexos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($sex->id); ?>" <?php echo e($sex->id == old('sexo_id',$atendimento->sexo_id) ? 'selected' : ''); ?>><?php echo e($sex->descricao); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'idade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>

                                            </div>

                                            <div class="col-lg-1 col-sm-12">
                                                <div class="form-group<?php echo e($errors->has('online') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-online"><?php echo e(__('Online')); ?></label><br>
                                                    <label class="custom-toggle mt-1">

                                                         <?php if($atendimento->isOnline()): ?>
                                                            <input type="hidden" name="online" value="1">
                                                        <?php else: ?>
                                                            <input type="hidden" name="online" value="0">
                                                        <?php endif; ?>
                                                        <input type="checkbox"  name="isonline" id="isonline"  <?php echo e($atendimento->isOnline() ? 'checked' : ''); ?> >
                                                        <span class="custom-toggle-slider rounded-circle"  data-label-off="Não" data-label-on="Sim" ></span>

                                                    </label>

                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'online'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>

                                            </div>
                                    <div class="col-lg-1 col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('online') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-online"><?php echo e(__('Retorno')); ?></label><br>
                                            <label class="custom-toggle mt-1">

                                                <?php if($atendimento->isOnline()): ?>
                                                    <input type="hidden" name="online" value="1">
                                                <?php else: ?>
                                                    <input type="hidden" name="online" value="0">
                                                <?php endif; ?>
                                                <input type="checkbox"  name="isonline" id="isonline"  <?php echo e($atendimento->isOnline() ? 'checked' : ''); ?> >
                                                <span class="custom-toggle-slider rounded-circle"  data-label-off="Não" data-label-on="Sim" ></span>

                                            </label>

                                            <?php echo $__env->make('alerts.feedback', ['field' => 'online'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>

                                    </div>

                                        </div>
                                <div class="row">

                                            <div class="col-lg-4 col-sm-12">
                                                <div class="form-group<?php echo e($errors->has('whats') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-nome"><?php echo e(__('Whats')); ?></label>
                                                    <input type="text" name="whats" id="input-whats" class="form-control<?php echo e($errors->has('whats') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Whats')); ?>" value="<?php echo e(old('whats', $atendimento->whats??'')); ?>" required autofocus>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'whats'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>

                                            </div>
                                            <div class="col-lg-4 col-sm-12">
                                                <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-idade"><?php echo e(__('E-mail')); ?></label>
                                                    <input type="text" name="email" id="input-email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email', $atendimento->email??'')); ?>" required autofocus>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'idade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>

                                            </div>
                                    <div class="col-lg-2 col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('necessidade_id') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-idade"><?php echo e(__('Necessidade')); ?></label>
                                            <select name="necessidade_id" id="input-necessidade" class="form-control<?php echo e($errors->has('necessidade_id') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Necessidade')); ?>" required>
                                                <option value="">-</option>
                                                <?php $__currentLoopData = $necessidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($nec->id); ?>" <?php echo e($nec->id == old('necessidade_id',$atendimento->necessidade_id) ? 'selected' : ''); ?>><?php echo e($nec->descricao); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'idade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>

                                    </div>
                                            <div class="col-lg-4 col-sm-12">
                                                <div class="form-group<?php echo e($errors->has('atuacao_id') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-atuacao"><?php echo e(__('Atuação')); ?></label>
                                                    <select name="atuacao_id" id="input-atuacao" class="form-control<?php echo e($errors->has('atuacao_id') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Atuação')); ?>" required>
                                                        <?php $__currentLoopData = $atuacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($atu->id); ?>" <?php echo e($atu->id == old('atuacao_id',$atendimento->atuacao_id) ? 'selected' : ''); ?>><?php echo e($atu->descricao); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'idade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>

                                            </div>

                                        </div>
                                <div class="row">
                                            <div class="col">
                                                <div class="form-group<?php echo e($errors->has('situacao_id') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-situacao"><?php echo e(__('Situação')); ?></label>
                                                    <select name="situacao_id" id="input-situacao" class="form-control<?php echo e($errors->has('situacao_id') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Situação')); ?>" required>
                                                        <?php $__currentLoopData = $situacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($sit->id); ?>" <?php echo e($sit->id == old('situacao_id',$atendimento->situacao_id) ? 'selected' : ''); ?>><?php echo e($sit->descricao); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'idade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-group<?php echo e($errors->has('user_id') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-user_id"><?php echo e(__('Advogado')); ?></label>
                                                    <select name="user_id" id="input-user_id" class="form-control<?php echo e($errors->has('user_id') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Advogado')); ?>" required>
                                                        <?php $__currentLoopData = $advogados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($adv->id); ?>" <?php echo e($adv->id == old('user_id',$atendimento->user_id) ? 'selected' : ''); ?>><?php echo e($adv->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'idade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-group<?php echo e($errors->has('dataagendamento') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-user_id"><?php echo e(__('Data da Consulta')); ?></label>

                                                    <?php if(empty($atendimento->dataagendamento)): ?>
                                                        <input type="datetime-local" id="input-data" class="form-control" name="dataagendamento" value="" >
                                                    <?php else: ?>
                                                        <input type="datetime-local" id="input-data" class="form-control" name="dataagendamento" value="<?php echo e(date('Y-m-d\TH:i', strtotime($atendimento->dataagendamento)) ?? ''); ?>" >
                                                    <?php endif; ?>

                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'dataagendamento'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>

                                        </div>
                                <div class="row">
                                            <div class="col">
                                                <div class="form-group<?php echo e($errors->has('cidade_id') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-cidade"><?php echo e(__('Cidade')); ?></label>
                                                    <select name="cidade_id" id="cidade_id" class="form-control<?php echo e($errors->has('cidade_id') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Cidade')); ?>" >
                                                        <option value="">Selecione</option>
                                                        <?php $__currentLoopData = $cidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($cid->id); ?>" <?php echo e($cid->id == old('cidade_id',$atendimento->cidade_id) ? 'selected' : ''); ?>><?php echo e($cid->nome); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php echo $__env->make('alerts.feedback', ['field' => 'idade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>


                                        </div>
                                <div class="row">
                                            <div class="col text-center">
                                                <button type="submit" class="btn btn-success  btn-lg"><?php echo e(__('Salvar')); ?></button>

                                            </div>
                                        </div>
                            </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-12 order-xl-1">
                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Obeservações')); ?></h3>
                            </div>

                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 col-sm-12">
                                <div class="mb-1">
                                    <?php $__currentLoopData = $atendimento->observacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="media media-comment mb-3">
                                            <img alt="Image placeholder" class="avatar avatar-lg media-comment-avatar rounded-circle" src="<?php echo e($obs->user->picture ?? ''); ?>">
                                            <div class="media-body">
                                                <div class="media-comment-text">
                                                    <h6 class="h5 mt-0"><?php echo e($obs->user->name); ?></h6>
                                                    <p class="text-sm lh-160"><?php echo e($obs->descricao); ?></p>
                                                    <div class="icon-actions">
                                                        <a href="#" class="like active">

                                                            <span class="text-muted small"><?php echo e($obs->data); ?></span>
                                                        </a>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($atendimento->id): ?>

                                        <form method="POST" action="<?php echo e(route('observacao.store')); ?>" autocomplete="off">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>


                                            <div class="media align-items-center">
                                                <img alt="Image placeholder" class="avatar avatar-lg rounded-circle mr-4" src="<?php echo e(auth()->user()->picture); ?>">
                                                <div class="media-body">

                                                    <input type="hidden" name="atendimento_id" id="input-id" class="form-control"  value="<?php echo e($atendimento->id??''); ?>"  >
                                                    <input type="hidden" name="user_id" id="input-id" class="form-control"  value="<?php echo e(auth()->user()->id ??''); ?>"  >
                                                    <textarea name="descricao" class="form-control" placeholder="Escreva sua observação" rows="1"></textarea>

                                                </div>
                                            </div>
                                            <div class="row mt-3">
                                                <div class="col text-center">
                                                    <button type="submit" class="btn btn-success  btn-lg"><?php echo e(__('Salvar')); ?></button>

                                                </div>
                                            </div>
                                        </form>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>

                    </div>




                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>






<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/datatables.net-select-bs4/css/select.bootstrap4.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/datatables.net-select/js/dataTables.select.min.js"></script>

    <script type="text/javascript">


        var switchStatus = false;
        $("#isonline").on('change', function() {
            if ($(this).is(':checked')) {
                document.getElementById('cidade_id').value = 0;
                $("#cidade_id").prop('disabled',true);
            }
            else {
                switchStatus = $(this).is(':checked');
                document.getElementById('cidade_id').value = 1;
                $("#cidade_id").prop('disabled',false);
            }
        });


    </script>
    <script>
        window.onload = function () {
            if ( $("#isonline").is(':checked')) {
                document.getElementById('cidade_id').value = 0;
                $("#cidade_id").prop('disabled',true);
            }
            // else {
            //     switchStatus = $(this).is(':checked');
            //     document.getElementById('cidade_id').value = 1;
            //     $("#cidade_id").prop('disabled',false);
            // }
        }
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => __('Atendimentos Management'),
    'parentSection' => 'laravel',
    'elementName' => 'atendimentos-management'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chronos\resources\views/atendimentos/show.blade.php ENDPATH**/ ?>