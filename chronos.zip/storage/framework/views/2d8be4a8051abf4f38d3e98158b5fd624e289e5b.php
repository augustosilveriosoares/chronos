<div class="row align-items-center justify-content-lg-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-lg-left text-muted">
            &copy; <?php echo e(now()->year); ?> <a href="https://www.fkprevidencia.adv.br" class="font-weight-bold ml-1" target="_blank">FK Advocacia Previdenciária</a>
        </div>
    </div>
    <div class="col-xl-6">

















    </div>
</div>
<?php /**PATH C:\xampp\htdocs\chronos\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>